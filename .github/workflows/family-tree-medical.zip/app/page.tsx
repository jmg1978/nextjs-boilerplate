import { FamilyTree } from "@/components/family-tree"
import { AddFamilyMemberForm } from "@/components/add-family-member-form"
import { MedicalHistoryView } from "@/components/medical-history-view"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FamilyProvider } from "@/context/family-context"

export default function Home() {
  return (
    <FamilyProvider>
      <main className="container mx-auto py-6 px-4">
        <h1 className="text-3xl font-bold mb-6 text-center">Family Tree & Medical History Tracker</h1>

        <Tabs defaultValue="tree" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="tree">Family Tree</TabsTrigger>
            <TabsTrigger value="add">Add Family Member</TabsTrigger>
            <TabsTrigger value="medical">Medical History</TabsTrigger>
          </TabsList>

          <TabsContent value="tree" className="mt-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Your Family Tree</h2>
              <FamilyTree />
            </div>
          </TabsContent>

          <TabsContent value="add" className="mt-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Add Family Member</h2>
              <AddFamilyMemberForm />
            </div>
          </TabsContent>

          <TabsContent value="medical" className="mt-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Medical History</h2>
              <MedicalHistoryView />
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </FamilyProvider>
  )
}
