import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date)
}

export function getRelationshipLabel(relationship: string): string {
  const labels: Record<string, string> = {
    self: "Self",
    spouse: "Spouse/Partner",
    parent: "Parent",
    child: "Child",
    sibling: "Sibling",
    grandparent: "Grandparent",
    "aunt-uncle": "Aunt/Uncle",
    cousin: "Cousin",
    other: "Other",
  }

  return labels[relationship] || relationship
}

export function getAbuseTypeLabel(abuseType: string): string {
  const labels: Record<string, string> = {
    physicalAbuse: "Physical Abuse",
    emotionalAbuse: "Emotional Abuse",
    sexualAbuse: "Sexual Abuse",
    verbalAbuse: "Verbal Abuse",
    financialAbuse: "Financial Abuse",
    neglect: "Neglect",
    domesticViolence: "Domestic Violence",
    childAbuse: "Child Abuse",
    elderAbuse: "Elder Abuse",
    abandoned: "Abandoned",
    adopted: "Adopted",
    wasAbuser: "Was Abuser",
  }

  return labels[abuseType] || abuseType
}
