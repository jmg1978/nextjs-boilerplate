"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Define types
export interface MedicalCondition {
  condition: string
  diagnosisYear: string
  notes: string
}

export interface FamilyMember {
  id: string
  name: string
  age: number
  gender: string
  relationship: string
  medicalHistory?: MedicalCondition[]
  children?: string[]
  familySize?: string
  detailedMedicalHistory?: {
    mentalHealth: {
      anxiety: boolean
      bipolarDisorder: boolean
      childMentalHealth: boolean
      compulsiveGambling: boolean
      delirium: boolean
      depression: boolean
      eatingDisorders: boolean
      generalMentalHealth: boolean
      moodDisorders: boolean
      ocd: boolean
      olderAdultMentalHealth: boolean
      panicDisorder: boolean
      personalityDisorders: boolean
      phobias: boolean
      ptsd: boolean
      psychoticDisorders: boolean
      schizophrenia: boolean
      selfHarm: boolean
      suicide: boolean
      alzheimers: boolean
      dementia: boolean
      notes: string
    }
    allergies: {
      aspirin: boolean
      ibuprofen: boolean
      acetaminophen: boolean
      codeine: boolean
      penicillin: boolean
      erythromycin: boolean
      tetracycline: boolean
      sulfa: boolean
      localAnesthetic: boolean
      fluoride: boolean
      metals: boolean
      metalsDetails: string
      latex: boolean
      other: boolean
      otherDetails: string
    }
    conditions: Record<string, boolean | string>
    substanceUse: {
      alcohol: boolean
      marijuana: boolean
      prescriptionDrugs: boolean
      inhalants: boolean
      hallucinogens: boolean
      amphetamines: boolean
      benzodiazepines: boolean
      sedatives: boolean
      frequency: string
      notes: string
    }
    familySize: {
      numberOfChildren: string
    }
    abuseHistory: {
      physicalAbuse: boolean
      emotionalAbuse: boolean
      sexualAbuse: boolean
      verbalAbuse: boolean
      financialAbuse: boolean
      neglect: boolean
      domesticViolence: boolean
      childAbuse: boolean
      elderAbuse: boolean
      abandoned: boolean
      adopted: boolean
      wasAbuser: boolean
      abuseDetails: string
      abuserRelationship: string
      ageWhenAbused: string
      notes: string
    }
  }
}

interface FamilyContextType {
  familyMembers: FamilyMember[]
  addFamilyMember: (member: FamilyMember, parentId?: string) => void
  updateFamilyMember: (id: string, updates: Partial<FamilyMember>) => void
  removeFamilyMember: (id: string) => void
}

// Create context
const FamilyContext = createContext<FamilyContextType | undefined>(undefined)

// Provider component
export function FamilyProvider({ children }: { children: ReactNode }) {
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([])

  // Load data from localStorage on initial render
  useEffect(() => {
    const savedData = localStorage.getItem("familyTreeData")
    if (savedData) {
      try {
        setFamilyMembers(JSON.parse(savedData))
      } catch (error) {
        console.error("Failed to parse saved family data:", error)
      }
    }
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem("familyTreeData", JSON.stringify(familyMembers))
  }, [familyMembers])

  const addFamilyMember = (member: FamilyMember, parentId?: string) => {
    setFamilyMembers((prev) => {
      const newMembers = [...prev, member]

      // If parentId is provided, update the parent's children array
      if (parentId) {
        return newMembers.map((m) => {
          if (m.id === parentId) {
            return {
              ...m,
              children: [...(m.children || []), member.id],
            }
          }
          return m
        })
      }

      return newMembers
    })
  }

  const updateFamilyMember = (id: string, updates: Partial<FamilyMember>) => {
    setFamilyMembers((prev) => prev.map((member) => (member.id === id ? { ...member, ...updates } : member)))
  }

  const removeFamilyMember = (id: string) => {
    // First, find any parents of this member and remove the id from their children array
    const updatedMembers = familyMembers.map((member) => {
      if (member.children?.includes(id)) {
        return {
          ...member,
          children: member.children.filter((childId) => childId !== id),
        }
      }
      return member
    })

    // Then remove the member itself
    setFamilyMembers(updatedMembers.filter((member) => member.id !== id))
  }

  return (
    <FamilyContext.Provider
      value={{
        familyMembers,
        addFamilyMember,
        updateFamilyMember,
        removeFamilyMember,
      }}
    >
      {children}
    </FamilyContext.Provider>
  )
}

// Custom hook to use the context
export function useFamilyContext() {
  const context = useContext(FamilyContext)
  if (context === undefined) {
    throw new Error("useFamilyContext must be used within a FamilyProvider")
  }
  return context
}
