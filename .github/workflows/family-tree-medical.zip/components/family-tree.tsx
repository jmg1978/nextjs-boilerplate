"use client"

import { useState } from "react"
import { useFamilyContext } from "@/context/family-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { User, Users, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

// Define the FamilyMember type
interface FamilyMember {
  id: string
  name: string
  age: number
  gender: string
  relationship: string
  children?: string[]
  medicalHistory?: { condition: string; diagnosisYear: number }[]
}

export function FamilyTree() {
  const { familyMembers } = useFamilyContext()
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null)
  const [open, setOpen] = useState(false)

  // Find root members (those without parents in the system)
  const rootMembers = familyMembers.filter((member) => !familyMembers.some((m) => m.children?.includes(member.id)))

  if (familyMembers.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center">
        <Users className="h-16 w-16 text-gray-400 mb-4" />
        <h3 className="text-xl font-medium mb-2">No family members yet</h3>
        <p className="text-gray-500 mb-4">Add your first family member to start building your tree</p>
        <Button variant="default" className="mt-2">
          Add Family Member
        </Button>
      </div>
    )
  }

  // Check if any family member has abuse history
  const hasAbuseHistory = familyMembers.some(
    (member) =>
      member.detailedMedicalHistory?.abuseHistory &&
      Object.entries(member.detailedMedicalHistory.abuseHistory).some(
        ([key, value]) =>
          value === true &&
          key !== "abuseDetails" &&
          key !== "abuserRelationship" &&
          key !== "ageWhenAbused" &&
          key !== "notes",
      ),
  )

  return (
    <div className="w-full">
      {hasAbuseHistory && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-md flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-500" />
          <p className="text-sm text-amber-700">
            Some family members have recorded abuse history. This information is sensitive and should be handled with
            care.
          </p>
        </div>
      )}

      <ScrollArea className="h-[500px] w-full rounded-md border p-4">
        <div className="flex flex-col items-center">
          {rootMembers.map((member) => (
            <TreeNode
              key={member.id}
              member={member}
              allMembers={familyMembers}
              onSelectMember={(member) => {
                setSelectedMember(member)
                setOpen(true)
              }}
            />
          ))}
        </div>
      </ScrollArea>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{selectedMember?.name}</DialogTitle>
          </DialogHeader>
          {selectedMember && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <span className="text-sm font-medium">Age:</span>
                <span className="col-span-3">{selectedMember.age}</span>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <span className="text-sm font-medium">Gender:</span>
                <span className="col-span-3">{selectedMember.gender}</span>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <span className="text-sm font-medium">Relationship:</span>
                <span className="col-span-3">{selectedMember.relationship}</span>
              </div>

              <div className="mt-2">
                <h4 className="text-sm font-medium mb-2">Medical History:</h4>
                <div className="bg-gray-50 p-3 rounded-md">
                  {selectedMember.medicalHistory?.length ? (
                    <ul className="list-disc pl-5 space-y-1">
                      {selectedMember.medicalHistory.map((item, index) => (
                        <li key={index} className="text-sm">
                          {item.condition} ({item.diagnosisYear})
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-gray-500">No medical history recorded</p>
                  )}
                </div>
              </div>

              {/* Display abuse history if present */}
              {selectedMember.detailedMedicalHistory?.abuseHistory &&
                Object.entries(selectedMember.detailedMedicalHistory.abuseHistory).some(
                  ([key, value]) =>
                    value === true &&
                    key !== "abuseDetails" &&
                    key !== "abuserRelationship" &&
                    key !== "ageWhenAbused" &&
                    key !== "notes",
                ) && (
                  <div className="mt-2">
                    <h4 className="text-sm font-medium mb-2 flex items-center">
                      <AlertTriangle className="h-4 w-4 text-amber-500 mr-1" />
                      Abuse History:
                    </h4>
                    <div className="bg-amber-50 p-3 rounded-md border border-amber-200">
                      <div className="flex flex-wrap gap-1 mb-2">
                        {Object.entries(selectedMember.detailedMedicalHistory.abuseHistory).map(([key, value]) => {
                          if (
                            value === true &&
                            key !== "abuseDetails" &&
                            key !== "abuserRelationship" &&
                            key !== "ageWhenAbused" &&
                            key !== "notes"
                          ) {
                            const label = key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())
                            return (
                              <Badge
                                key={key}
                                variant="outline"
                                className="bg-amber-100 text-amber-800 border-amber-200"
                              >
                                {label}
                              </Badge>
                            )
                          }
                          return null
                        })}
                      </div>
                      {selectedMember.detailedMedicalHistory.abuseHistory.notes && (
                        <p className="text-xs text-amber-800 mt-1">
                          {selectedMember.detailedMedicalHistory.abuseHistory.notes}
                        </p>
                      )}
                    </div>
                  </div>
                )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function TreeNode({
  member,
  allMembers,
  onSelectMember,
}: {
  member: FamilyMember
  allMembers: FamilyMember[]
  onSelectMember: (member: FamilyMember) => void
}) {
  // Find children of this member
  const children = allMembers.filter((m) => member.children?.includes(m.id))

  // Check if member has abuse history
  const hasAbuseHistory =
    member.detailedMedicalHistory?.abuseHistory &&
    Object.entries(member.detailedMedicalHistory.abuseHistory).some(
      ([key, value]) =>
        value === true &&
        key !== "abuseDetails" &&
        key !== "abuserRelationship" &&
        key !== "ageWhenAbused" &&
        key !== "notes",
    )

  return (
    <div className="flex flex-col items-center">
      <Card
        className={`w-64 mb-2 cursor-pointer hover:shadow-md transition-shadow ${
          hasAbuseHistory ? "border-amber-300" : ""
        }`}
        onClick={() => onSelectMember(member)}
      >
        <CardContent className="p-4 flex items-center gap-3">
          <div className={`p-2 rounded-full ${hasAbuseHistory ? "bg-amber-100" : "bg-gray-100"}`}>
            <User className={`h-5 w-5 ${hasAbuseHistory ? "text-amber-600" : "text-gray-600"}`} />
          </div>
          <div>
            <h3 className="font-medium">{member.name}</h3>
            <p className="text-sm text-gray-500">{member.relationship}</p>
          </div>
          {hasAbuseHistory && <AlertTriangle className="h-4 w-4 text-amber-500 ml-auto" />}
        </CardContent>
      </Card>

      {children.length > 0 && (
        <>
          <div className="w-px h-4 bg-gray-300"></div>
          <div className="flex flex-row items-start">
            {children.map((child, index) => (
              <div key={child.id} className="flex flex-col items-center">
                {index > 0 && <div className="w-8"></div>}
                <TreeNode member={child} allMembers={allMembers} onSelectMember={onSelectMember} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
