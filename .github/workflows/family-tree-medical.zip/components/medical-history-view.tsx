"use client"

import { useState } from "react"
import { useFamilyContext } from "@/context/family-context"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, AlertCircle, FileText, User, AlertTriangle } from "lucide-react"
import { getAbuseTypeLabel } from "@/lib/utils"

export function MedicalHistoryView() {
  const { familyMembers } = useFamilyContext()
  const [selectedMemberId, setSelectedMemberId] = useState<string>("")
  const [activeTab, setActiveTab] = useState("conditions")

  const selectedMember = selectedMemberId ? familyMembers.find((m) => m.id === selectedMemberId) : null

  // Count medical conditions across family
  const conditionCounts: Record<string, number> = {}
  const mentalHealthCounts: Record<string, number> = {}
  const allergyCounts: Record<string, number> = {}
  const substanceUseCounts: Record<string, number> = {}
  const abuseCounts: Record<string, number> = {}

  familyMembers.forEach((member) => {
    // Count from medicalHistory array
    member.medicalHistory?.forEach((history) => {
      if (history.condition) {
        conditionCounts[history.condition] = (conditionCounts[history.condition] || 0) + 1
      }
    })

    // Count from detailed medical history
    if (member.detailedMedicalHistory) {
      // Mental health conditions
      Object.entries(member.detailedMedicalHistory.mentalHealth).forEach(([key, value]) => {
        if (value === true) {
          const formattedKey = key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())
          mentalHealthCounts[formattedKey] = (mentalHealthCounts[formattedKey] || 0) + 1
        }
      })

      // Allergies
      Object.entries(member.detailedMedicalHistory.allergies).forEach(([key, value]) => {
        if (value === true && key !== "otherDetails" && key !== "metalsDetails") {
          const formattedKey = key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())
          allergyCounts[formattedKey] = (allergyCounts[formattedKey] || 0) + 1
        }
      })

      // Substance use
      Object.entries(member.detailedMedicalHistory.substanceUse).forEach(([key, value]) => {
        if (value === true && key !== "frequency" && key !== "notes") {
          const formattedKey = key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())
          substanceUseCounts[formattedKey] = (substanceUseCounts[formattedKey] || 0) + 1
        }
      })

      // Count from abuse history
      if (member.detailedMedicalHistory?.abuseHistory) {
        Object.entries(member.detailedMedicalHistory.abuseHistory).forEach(([key, value]) => {
          if (
            value === true &&
            key !== "abuseDetails" &&
            key !== "abuserRelationship" &&
            key !== "ageWhenAbused" &&
            key !== "notes"
          ) {
            const formattedKey = getAbuseTypeLabel(key)
            abuseCounts[formattedKey] = (abuseCounts[formattedKey] || 0) + 1
          }
        })
      }
    }
  })

  // Sort conditions by frequency
  const sortedConditions = Object.entries(conditionCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5) // Top 5 conditions

  const sortedMentalHealth = Object.entries(mentalHealthCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  const sortedAllergies = Object.entries(allergyCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  const sortedSubstanceUse = Object.entries(substanceUseCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  const sortedAbuseHistory = Object.entries(abuseCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  if (familyMembers.length === 0) {
    return (
      <div className="text-center p-8">
        <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-lg font-medium">No family members yet</h3>
        <p className="mt-1 text-gray-500">Add family members to start tracking medical history</p>
      </div>
    )
  }

  const totalMentalHealthConditions = Object.keys(mentalHealthCounts).length
  const totalAllergies = Object.keys(allergyCounts).length
  const totalSubstanceUse = Object.keys(substanceUseCounts).length
  const totalAbuseHistory = Object.keys(abuseCounts).length

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Family Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{familyMembers.length}</div>
            <p className="text-xs text-gray-500 mt-1">Total members in family tree</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Medical Conditions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{Object.keys(conditionCounts).length}</div>
            <p className="text-xs text-gray-500 mt-1">Unique conditions recorded</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Mental Health</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMentalHealthConditions}</div>
            <p className="text-xs text-gray-500 mt-1">Mental health conditions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Abuse History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalAbuseHistory}</div>
            <p className="text-xs text-gray-500 mt-1">Types of abuse recorded</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Common Conditions</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="conditions">Conditions</TabsTrigger>
                <TabsTrigger value="mentalHealth">Mental Health</TabsTrigger>
                <TabsTrigger value="abuseHistory">Abuse History</TabsTrigger>
              </TabsList>
              <TabsContent value="conditions" className="pt-4">
                {sortedConditions.length > 0 ? (
                  <div className="space-y-4">
                    {sortedConditions.map(([condition, count]) => (
                      <div key={condition} className="flex justify-between items-center">
                        <span className="text-sm">{condition}</span>
                        <Badge variant="outline">{count} members</Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <FileText className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2">No medical conditions recorded yet</p>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="mentalHealth" className="pt-4">
                {sortedMentalHealth.length > 0 ? (
                  <div className="space-y-4">
                    {sortedMentalHealth.map(([condition, count]) => (
                      <div key={condition} className="flex justify-between items-center">
                        <span className="text-sm">{condition}</span>
                        <Badge variant="outline">{count} members</Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <FileText className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2">No mental health conditions recorded yet</p>
                  </div>
                )}
              </TabsContent>
              <TabsContent value="abuseHistory" className="pt-4">
                {sortedAbuseHistory.length > 0 ? (
                  <div className="space-y-4">
                    {sortedAbuseHistory.map(([abuse, count]) => (
                      <div key={abuse} className="flex justify-between items-center">
                        <span className="text-sm">{abuse}</span>
                        <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200">
                          {count} members
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    <FileText className="h-8 w-8 mx-auto text-gray-400" />
                    <p className="mt-2">No abuse history recorded yet</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Individual Medical History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Select value={selectedMemberId} onValueChange={setSelectedMemberId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select family member" />
                </SelectTrigger>
                <SelectContent>
                  {familyMembers.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.name} ({member.relationship})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedMember ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-gray-100 p-2 rounded-full">
                    <User className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">{selectedMember.name}</h3>
                    <p className="text-sm text-gray-500">
                      {selectedMember.age} years old • {selectedMember.gender}
                    </p>
                  </div>
                </div>

                <Tabs defaultValue="medical">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="medical">Medical History</TabsTrigger>
                    <TabsTrigger value="abuse">
                      <div className="flex items-center">
                        <AlertTriangle className="h-4 w-4 text-amber-500 mr-1" />
                        Abuse History
                      </div>
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="medical">
                    {selectedMember.medicalHistory && selectedMember.medicalHistory.length > 0 ? (
                      <ScrollArea className="h-[300px]">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Condition</TableHead>
                              <TableHead>Year Diagnosed</TableHead>
                              <TableHead>Notes</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedMember.medicalHistory.map((history, index) => (
                              <TableRow key={index}>
                                <TableCell className="font-medium">{history.condition}</TableCell>
                                <TableCell>{history.diagnosisYear || "Unknown"}</TableCell>
                                <TableCell className="max-w-[200px] truncate">{history.notes || "—"}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <Activity className="h-8 w-8 mx-auto text-gray-400" />
                        <p className="mt-2">No medical history recorded for this member</p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="abuse">
                    {selectedMember.detailedMedicalHistory?.abuseHistory &&
                    Object.entries(selectedMember.detailedMedicalHistory.abuseHistory).some(
                      ([key, value]) =>
                        value === true &&
                        key !== "abuseDetails" &&
                        key !== "abuserRelationship" &&
                        key !== "ageWhenAbused" &&
                        key !== "notes",
                    ) ? (
                      <div className="space-y-4">
                        <div className="bg-amber-50 p-4 rounded-md border border-amber-200">
                          <h3 className="text-sm font-medium text-amber-800 mb-2">Abuse History</h3>
                          <div className="flex flex-wrap gap-2 mb-3">
                            {Object.entries(selectedMember.detailedMedicalHistory.abuseHistory).map(([key, value]) => {
                              if (
                                value === true &&
                                key !== "abuseDetails" &&
                                key !== "abuserRelationship" &&
                                key !== "ageWhenAbused" &&
                                key !== "notes"
                              ) {
                                return (
                                  <Badge
                                    key={key}
                                    variant="outline"
                                    className="bg-amber-100 text-amber-800 border-amber-200"
                                  >
                                    {getAbuseTypeLabel(key)}
                                  </Badge>
                                )
                              }
                              return null
                            })}
                          </div>

                          {selectedMember.detailedMedicalHistory.abuseHistory.abuserRelationship && (
                            <div className="mb-2">
                              <span className="text-xs font-medium text-amber-800">Relationship to abuser: </span>
                              <span className="text-xs text-amber-700">
                                {selectedMember.detailedMedicalHistory.abuseHistory.abuserRelationship}
                              </span>
                            </div>
                          )}

                          {selectedMember.detailedMedicalHistory.abuseHistory.ageWhenAbused && (
                            <div className="mb-2">
                              <span className="text-xs font-medium text-amber-800">Age when abuse occurred: </span>
                              <span className="text-xs text-amber-700">
                                {selectedMember.detailedMedicalHistory.abuseHistory.ageWhenAbused}
                              </span>
                            </div>
                          )}

                          {selectedMember.detailedMedicalHistory.abuseHistory.abuseDetails && (
                            <div className="mb-2">
                              <span className="text-xs font-medium text-amber-800">Details: </span>
                              <span className="text-xs text-amber-700">
                                {selectedMember.detailedMedicalHistory.abuseHistory.abuseDetails}
                              </span>
                            </div>
                          )}

                          {selectedMember.detailedMedicalHistory.abuseHistory.notes && (
                            <div>
                              <span className="text-xs font-medium text-amber-800">Additional notes: </span>
                              <span className="text-xs text-amber-700">
                                {selectedMember.detailedMedicalHistory.abuseHistory.notes}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <AlertTriangle className="h-8 w-8 mx-auto text-gray-400" />
                        <p className="mt-2">No abuse history recorded for this member</p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <p>Select a family member to view their medical history</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
