"use client"

import type React from "react"

import { useState } from "react"
import { useFamilyContext } from "@/context/family-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { v4 as uuidv4 } from "uuid"
import { AlertTriangle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// Define the FamilyMember type
interface FamilyMember {
  id: string
  name: string
  age: number
  gender: string
  relationship: string
  medicalHistory: Array<{ condition: string; diagnosisYear: string; notes: string }>
  children: string[]
  familySize?: string
  detailedMedicalHistory?: any
}

export function AddFamilyMemberForm() {
  const { familyMembers, addFamilyMember } = useFamilyContext()

  const [name, setName] = useState("")
  const [age, setAge] = useState("")
  const [gender, setGender] = useState("")
  const [relationship, setRelationship] = useState("")
  const [parentId, setParentId] = useState("")

  // Medical history fields
  const [medicalHistory, setMedicalHistory] = useState({
    mentalHealth: {
      anxiety: false,
      bipolarDisorder: false,
      childMentalHealth: false,
      compulsiveGambling: false,
      delirium: false,
      depression: false,
      eatingDisorders: false,
      generalMentalHealth: false,
      moodDisorders: false,
      ocd: false,
      olderAdultMentalHealth: false,
      panicDisorder: false,
      personalityDisorders: false,
      phobias: false,
      ptsd: false,
      psychoticDisorders: false,
      schizophrenia: false,
      selfHarm: false,
      suicide: false,
      alzheimers: false,
      dementia: false,
      notes: "",
    },
    allergies: {
      aspirin: false,
      ibuprofen: false,
      acetaminophen: false,
      codeine: false,
      penicillin: false,
      erythromycin: false,
      tetracycline: false,
      sulfa: false,
      localAnesthetic: false,
      fluoride: false,
      metals: false,
      metalsDetails: "",
      latex: false,
      other: false,
      otherDetails: "",
    },
    conditions: {
      heartProblems: false,
      infectiveEndocarditis: false,
      artificialHeartValve: false,
      pacemaker: false,
      artificialProsthesis: false,
      rheumaticFever: false,
      bloodPressure: false,
      stroke: false,
      anemia: false,
      prolongedBleeding: false,
      emphysema: false,
      tuberculosis: false,
      asthma: false,
      breathingProblems: false,
      kidneyDisease: false,
      liverDisease: false,
      jaundice: false,
      thyroidDisease: false,
      hormoneDeficiency: false,
      highCholesterol: false,
      diabetes: false,
      diabetesHbA1c: "",
      stomachUlcer: false,
      digestiveDisorders: false,
      osteoporosis: false,
      arthritis: false,
      glaucoma: false,
      contactLenses: false,
      headNeckInjuries: false,
      epilepsy: false,
      neurologicDisorders: false,
      viralInfections: false,
      mouthLumps: false,
      hives: false,
      sti: false,
      hepatitis: false,
      hepatitisType: "",
      hiv: false,
      tumor: false,
      radiationTherapy: false,
      chemotherapy: false,
      emotionalProblems: false,
      psychiatricTreatment: false,
      antidepressantMedication: false,
      substanceUse: false,
      otherIllness: false,
      recentHealthChange: false,
      weightManagementMeds: false,
      dietarySupplements: false,
      fatigue: false,
      frequentHeadaches: false,
      tobacco: false,
      touchyPerson: false,
      unhappyDepressed: false,
      birthControlPills: false,
      pregnant: false,
      prostateDisorders: false,
      hairLoss: false,
      notes: "",
    },
    substanceUse: {
      alcohol: false,
      marijuana: false,
      prescriptionDrugs: false,
      inhalants: false,
      hallucinogens: false,
      amphetamines: false,
      benzodiazepines: false,
      sedatives: false,
      frequency: "",
      notes: "",
    },
    familySize: {
      numberOfChildren: "",
    },
    abuseHistory: {
      physicalAbuse: false,
      emotionalAbuse: false,
      sexualAbuse: false,
      verbalAbuse: false,
      financialAbuse: false,
      neglect: false,
      domesticViolence: false,
      childAbuse: false,
      elderAbuse: false,
      abandoned: false,
      adopted: false,
      wasAbuser: false,
      abuseDetails: "",
      abuserRelationship: "",
      ageWhenAbused: "",
      notes: "",
    },
  })

  const handleMentalHealthChange = (condition: string, value: boolean) => {
    setMedicalHistory({
      ...medicalHistory,
      mentalHealth: {
        ...medicalHistory.mentalHealth,
        [condition]: value,
      },
    })
  }

  const handleAllergiesChange = (allergy: string, value: boolean) => {
    setMedicalHistory({
      ...medicalHistory,
      allergies: {
        ...medicalHistory.allergies,
        [allergy]: value,
      },
    })
  }

  const handleConditionsChange = (condition: string, value: boolean | string) => {
    setMedicalHistory({
      ...medicalHistory,
      conditions: {
        ...medicalHistory.conditions,
        [condition]: value,
      },
    })
  }

  const handleSubstanceUseChange = (substance: string, value: boolean | string) => {
    setMedicalHistory({
      ...medicalHistory,
      substanceUse: {
        ...medicalHistory.substanceUse,
        [substance]: value,
      },
    })
  }

  const handleFamilySizeChange = (field: string, value: string) => {
    setMedicalHistory({
      ...medicalHistory,
      familySize: {
        ...medicalHistory.familySize,
        [field]: value,
      },
    })
  }

  const handleAbuseHistoryChange = (field: string, value: boolean | string) => {
    setMedicalHistory({
      ...medicalHistory,
      abuseHistory: {
        ...medicalHistory.abuseHistory,
        [field]: value,
      },
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Create a list of medical conditions from the checked items
    const medicalConditionsList = []

    // Add mental health conditions
    Object.entries(medicalHistory.mentalHealth).forEach(([key, value]) => {
      if (value === true) {
        medicalConditionsList.push({
          condition: key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase()),
          diagnosisYear: "",
          notes: medicalHistory.mentalHealth.notes,
        })
      }
    })

    // Add physical conditions
    Object.entries(medicalHistory.conditions).forEach(([key, value]) => {
      if (value === true) {
        medicalConditionsList.push({
          condition: key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase()),
          diagnosisYear: "",
          notes: medicalHistory.conditions.notes,
        })
      }
    })

    // Add allergies
    Object.entries(medicalHistory.allergies).forEach(([key, value]) => {
      if (value === true && key !== "otherDetails" && key !== "metalsDetails") {
        medicalConditionsList.push({
          condition: `Allergy: ${key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}`,
          diagnosisYear: "",
          notes:
            key === "other"
              ? medicalHistory.allergies.otherDetails
              : key === "metals"
                ? medicalHistory.allergies.metalsDetails
                : "",
        })
      }
    })

    // Add substance use
    Object.entries(medicalHistory.substanceUse).forEach(([key, value]) => {
      if (value === true && key !== "frequency" && key !== "notes") {
        medicalConditionsList.push({
          condition: `Substance Use: ${key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}`,
          diagnosisYear: "",
          notes: `Frequency: ${medicalHistory.substanceUse.frequency}. ${medicalHistory.substanceUse.notes}`,
        })
      }
    })

    // Add abuse history
    Object.entries(medicalHistory.abuseHistory).forEach(([key, value]) => {
      if (
        value === true &&
        key !== "abuseDetails" &&
        key !== "abuserRelationship" &&
        key !== "ageWhenAbused" &&
        key !== "notes"
      ) {
        medicalConditionsList.push({
          condition: `Abuse History: ${key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}`,
          diagnosisYear: "",
          notes: `Details: ${medicalHistory.abuseHistory.abuseDetails}. Abuser relationship: ${medicalHistory.abuseHistory.abuserRelationship}. Age when abused: ${medicalHistory.abuseHistory.ageWhenAbused}. ${medicalHistory.abuseHistory.notes}`,
        })
      }
    })

    const newMember: FamilyMember = {
      id: uuidv4(),
      name,
      age: Number.parseInt(age),
      gender,
      relationship,
      medicalHistory: medicalConditionsList,
      children: [],
      familySize: medicalHistory.familySize.numberOfChildren,
      detailedMedicalHistory: medicalHistory, // Store the full detailed medical history
    }

    // If parent is selected, update the parent's children array
    if (parentId && parentId !== "none") {
      addFamilyMember(newMember, parentId)
    } else {
      addFamilyMember(newMember)
    }

    // Reset form
    setName("")
    setAge("")
    setGender("")
    setRelationship("")
    setParentId("")
    // Reset medical history to default state
    setMedicalHistory({
      mentalHealth: {
        anxiety: false,
        bipolarDisorder: false,
        childMentalHealth: false,
        compulsiveGambling: false,
        delirium: false,
        depression: false,
        eatingDisorders: false,
        generalMentalHealth: false,
        moodDisorders: false,
        ocd: false,
        olderAdultMentalHealth: false,
        panicDisorder: false,
        personalityDisorders: false,
        phobias: false,
        ptsd: false,
        psychoticDisorders: false,
        schizophrenia: false,
        selfHarm: false,
        suicide: false,
        alzheimers: false,
        dementia: false,
        notes: "",
      },
      allergies: {
        aspirin: false,
        ibuprofen: false,
        acetaminophen: false,
        codeine: false,
        penicillin: false,
        erythromycin: false,
        tetracycline: false,
        sulfa: false,
        localAnesthetic: false,
        fluoride: false,
        metals: false,
        metalsDetails: "",
        latex: false,
        other: false,
        otherDetails: "",
      },
      conditions: {
        heartProblems: false,
        infectiveEndocarditis: false,
        artificialHeartValve: false,
        pacemaker: false,
        artificialProsthesis: false,
        rheumaticFever: false,
        bloodPressure: false,
        stroke: false,
        anemia: false,
        prolongedBleeding: false,
        emphysema: false,
        tuberculosis: false,
        asthma: false,
        breathingProblems: false,
        kidneyDisease: false,
        liverDisease: false,
        jaundice: false,
        thyroidDisease: false,
        hormoneDeficiency: false,
        highCholesterol: false,
        diabetes: false,
        diabetesHbA1c: "",
        stomachUlcer: false,
        digestiveDisorders: false,
        osteoporosis: false,
        arthritis: false,
        glaucoma: false,
        contactLenses: false,
        headNeckInjuries: false,
        epilepsy: false,
        neurologicDisorders: false,
        viralInfections: false,
        mouthLumps: false,
        hives: false,
        sti: false,
        hepatitis: false,
        hepatitisType: "",
        hiv: false,
        tumor: false,
        radiationTherapy: false,
        chemotherapy: false,
        emotionalProblems: false,
        psychiatricTreatment: false,
        antidepressantMedication: false,
        substanceUse: false,
        otherIllness: false,
        recentHealthChange: false,
        weightManagementMeds: false,
        dietarySupplements: false,
        fatigue: false,
        frequentHeadaches: false,
        tobacco: false,
        touchyPerson: false,
        unhappyDepressed: false,
        birthControlPills: false,
        pregnant: false,
        prostateDisorders: false,
        hairLoss: false,
        notes: "",
      },
      substanceUse: {
        alcohol: false,
        marijuana: false,
        prescriptionDrugs: false,
        inhalants: false,
        hallucinogens: false,
        amphetamines: false,
        benzodiazepines: false,
        sedatives: false,
        frequency: "",
        notes: "",
      },
      familySize: {
        numberOfChildren: "",
      },
      abuseHistory: {
        physicalAbuse: false,
        emotionalAbuse: false,
        sexualAbuse: false,
        verbalAbuse: false,
        financialAbuse: false,
        neglect: false,
        domesticViolence: false,
        childAbuse: false,
        elderAbuse: false,
        abandoned: false,
        adopted: false,
        wasAbuser: false,
        abuseDetails: "",
        abuserRelationship: "",
        ageWhenAbused: "",
        notes: "",
      },
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Full Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>

          <div>
            <Label htmlFor="age">Age</Label>
            <Input id="age" type="number" value={age} onChange={(e) => setAge(e.target.value)} required />
          </div>

          <div>
            <Label htmlFor="gender">Gender</Label>
            <Select value={gender} onValueChange={setGender} required>
              <SelectTrigger>
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="relationship">Relationship to You</Label>
            <Select value={relationship} onValueChange={setRelationship} required>
              <SelectTrigger>
                <SelectValue placeholder="Select relationship" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="self">Self</SelectItem>
                <SelectItem value="spouse">Spouse/Partner</SelectItem>
                <SelectItem value="parent">Parent</SelectItem>
                <SelectItem value="child">Child</SelectItem>
                <SelectItem value="sibling">Sibling</SelectItem>
                <SelectItem value="grandparent">Grandparent</SelectItem>
                <SelectItem value="aunt-uncle">Aunt/Uncle</SelectItem>
                <SelectItem value="cousin">Cousin</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="parent">Parent in Family Tree (optional)</Label>
            <Select value={parentId} onValueChange={setParentId}>
              <SelectTrigger>
                <SelectValue placeholder="Select parent (if applicable)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {familyMembers.map((member) => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.name} ({member.relationship})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Accordion type="multiple" className="w-full">
        <AccordionItem value="mental-health">
          <AccordionTrigger>Mental Health History</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="anxiety"
                    checked={medicalHistory.mentalHealth.anxiety}
                    onCheckedChange={(checked) => handleMentalHealthChange("anxiety", checked === true)}
                  />
                  <Label htmlFor="anxiety">Anxiety</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="bipolarDisorder"
                    checked={medicalHistory.mentalHealth.bipolarDisorder}
                    onCheckedChange={(checked) => handleMentalHealthChange("bipolarDisorder", checked === true)}
                  />
                  <Label htmlFor="bipolarDisorder">Bipolar Disorder</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="childMentalHealth"
                    checked={medicalHistory.mentalHealth.childMentalHealth}
                    onCheckedChange={(checked) => handleMentalHealthChange("childMentalHealth", checked === true)}
                  />
                  <Label htmlFor="childMentalHealth">Child Mental Health</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="compulsiveGambling"
                    checked={medicalHistory.mentalHealth.compulsiveGambling}
                    onCheckedChange={(checked) => handleMentalHealthChange("compulsiveGambling", checked === true)}
                  />
                  <Label htmlFor="compulsiveGambling">Compulsive Gambling</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="delirium"
                    checked={medicalHistory.mentalHealth.delirium}
                    onCheckedChange={(checked) => handleMentalHealthChange("delirium", checked === true)}
                  />
                  <Label htmlFor="delirium">Delirium</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="depression"
                    checked={medicalHistory.mentalHealth.depression}
                    onCheckedChange={(checked) => handleMentalHealthChange("depression", checked === true)}
                  />
                  <Label htmlFor="depression">Depression</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="eatingDisorders"
                    checked={medicalHistory.mentalHealth.eatingDisorders}
                    onCheckedChange={(checked) => handleMentalHealthChange("eatingDisorders", checked === true)}
                  />
                  <Label htmlFor="eatingDisorders">Eating Disorders</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="generalMentalHealth"
                    checked={medicalHistory.mentalHealth.generalMentalHealth}
                    onCheckedChange={(checked) => handleMentalHealthChange("generalMentalHealth", checked === true)}
                  />
                  <Label htmlFor="generalMentalHealth">General Mental Health</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="moodDisorders"
                    checked={medicalHistory.mentalHealth.moodDisorders}
                    onCheckedChange={(checked) => handleMentalHealthChange("moodDisorders", checked === true)}
                  />
                  <Label htmlFor="moodDisorders">Mood Disorders</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ocd"
                    checked={medicalHistory.mentalHealth.ocd}
                    onCheckedChange={(checked) => handleMentalHealthChange("ocd", checked === true)}
                  />
                  <Label htmlFor="ocd">Obsessive-Compulsive Disorder</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="olderAdultMentalHealth"
                    checked={medicalHistory.mentalHealth.olderAdultMentalHealth}
                    onCheckedChange={(checked) => handleMentalHealthChange("olderAdultMentalHealth", checked === true)}
                  />
                  <Label htmlFor="olderAdultMentalHealth">Older Adult Mental Health</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="panicDisorder"
                    checked={medicalHistory.mentalHealth.panicDisorder}
                    onCheckedChange={(checked) => handleMentalHealthChange("panicDisorder", checked === true)}
                  />
                  <Label htmlFor="panicDisorder">Panic Disorder</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="personalityDisorders"
                    checked={medicalHistory.mentalHealth.personalityDisorders}
                    onCheckedChange={(checked) => handleMentalHealthChange("personalityDisorders", checked === true)}
                  />
                  <Label htmlFor="personalityDisorders">Personality Disorders</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="phobias"
                    checked={medicalHistory.mentalHealth.phobias}
                    onCheckedChange={(checked) => handleMentalHealthChange("phobias", checked === true)}
                  />
                  <Label htmlFor="phobias">Phobias</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ptsd"
                    checked={medicalHistory.mentalHealth.ptsd}
                    onCheckedChange={(checked) => handleMentalHealthChange("ptsd", checked === true)}
                  />
                  <Label htmlFor="ptsd">Post-Traumatic Stress Disorder</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="psychoticDisorders"
                    checked={medicalHistory.mentalHealth.psychoticDisorders}
                    onCheckedChange={(checked) => handleMentalHealthChange("psychoticDisorders", checked === true)}
                  />
                  <Label htmlFor="psychoticDisorders">Psychotic Disorders</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="schizophrenia"
                    checked={medicalHistory.mentalHealth.schizophrenia}
                    onCheckedChange={(checked) => handleMentalHealthChange("schizophrenia", checked === true)}
                  />
                  <Label htmlFor="schizophrenia">Schizophrenia</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="selfHarm"
                    checked={medicalHistory.mentalHealth.selfHarm}
                    onCheckedChange={(checked) => handleMentalHealthChange("selfHarm", checked === true)}
                  />
                  <Label htmlFor="selfHarm">Self-Harm</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="suicide"
                    checked={medicalHistory.mentalHealth.suicide}
                    onCheckedChange={(checked) => handleMentalHealthChange("suicide", checked === true)}
                  />
                  <Label htmlFor="suicide">Suicide</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="alzheimers"
                    checked={medicalHistory.mentalHealth.alzheimers}
                    onCheckedChange={(checked) => handleMentalHealthChange("alzheimers", checked === true)}
                  />
                  <Label htmlFor="alzheimers">Alzheimer's</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="dementia"
                    checked={medicalHistory.mentalHealth.dementia}
                    onCheckedChange={(checked) => handleMentalHealthChange("dementia", checked === true)}
                  />
                  <Label htmlFor="dementia">Dementia</Label>
                </div>
              </div>

              <div className="mt-4">
                <Label htmlFor="mentalHealthNotes">Additional Notes</Label>
                <Textarea
                  id="mentalHealthNotes"
                  value={medicalHistory.mentalHealth.notes}
                  onChange={(e) =>
                    setMedicalHistory({
                      ...medicalHistory,
                      mentalHealth: {
                        ...medicalHistory.mentalHealth,
                        notes: e.target.value,
                      },
                    })
                  }
                  placeholder="Any additional details about mental health conditions"
                  rows={3}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="abuse-history">
          <AccordionTrigger>
            <div className="flex items-center">
              <AlertTriangle className="h-4 w-4 text-amber-500 mr-2" />
              Abuse History
            </div>
          </AccordionTrigger>
          <AccordionContent>
            <Alert className="mb-4 bg-amber-50 border-amber-200">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              <AlertTitle>Sensitive Information</AlertTitle>
              <AlertDescription>
                This section contains sensitive information about abuse history. Please ensure privacy and
                confidentiality.
              </AlertDescription>
            </Alert>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="physicalAbuse"
                    checked={medicalHistory.abuseHistory.physicalAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("physicalAbuse", checked === true)}
                  />
                  <Label htmlFor="physicalAbuse">Physical Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="emotionalAbuse"
                    checked={medicalHistory.abuseHistory.emotionalAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("emotionalAbuse", checked === true)}
                  />
                  <Label htmlFor="emotionalAbuse">Emotional Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="sexualAbuse"
                    checked={medicalHistory.abuseHistory.sexualAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("sexualAbuse", checked === true)}
                  />
                  <Label htmlFor="sexualAbuse">Sexual Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="verbalAbuse"
                    checked={medicalHistory.abuseHistory.verbalAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("verbalAbuse", checked === true)}
                  />
                  <Label htmlFor="verbalAbuse">Verbal Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="financialAbuse"
                    checked={medicalHistory.abuseHistory.financialAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("financialAbuse", checked === true)}
                  />
                  <Label htmlFor="financialAbuse">Financial Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="neglect"
                    checked={medicalHistory.abuseHistory.neglect}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("neglect", checked === true)}
                  />
                  <Label htmlFor="neglect">Neglect</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="domesticViolence"
                    checked={medicalHistory.abuseHistory.domesticViolence}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("domesticViolence", checked === true)}
                  />
                  <Label htmlFor="domesticViolence">Domestic Violence</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="childAbuse"
                    checked={medicalHistory.abuseHistory.childAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("childAbuse", checked === true)}
                  />
                  <Label htmlFor="childAbuse">Child Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="elderAbuse"
                    checked={medicalHistory.abuseHistory.elderAbuse}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("elderAbuse", checked === true)}
                  />
                  <Label htmlFor="elderAbuse">Elder Abuse</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="abandoned"
                    checked={medicalHistory.abuseHistory.abandoned}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("abandoned", checked === true)}
                  />
                  <Label htmlFor="abandoned">Abandoned</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="adopted"
                    checked={medicalHistory.abuseHistory.adopted}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("adopted", checked === true)}
                  />
                  <Label htmlFor="adopted">Adopted</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="wasAbuser"
                    checked={medicalHistory.abuseHistory.wasAbuser}
                    onCheckedChange={(checked) => handleAbuseHistoryChange("wasAbuser", checked === true)}
                  />
                  <Label htmlFor="wasAbuser">Was Abuser</Label>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="abuseDetails">Abuse Details</Label>
                <Textarea
                  id="abuseDetails"
                  value={medicalHistory.abuseHistory.abuseDetails}
                  onChange={(e) => handleAbuseHistoryChange("abuseDetails", e.target.value)}
                  placeholder="Provide details about the abuse"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="abuserRelationship">Relationship to Abuser</Label>
                <Input
                  id="abuserRelationship"
                  value={medicalHistory.abuseHistory.abuserRelationship}
                  onChange={(e) => handleAbuseHistoryChange("abuserRelationship", e.target.value)}
                  placeholder="e.g., Parent, Spouse, Relative, etc."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="ageWhenAbused">Age When Abuse Occurred</Label>
                <Input
                  id="ageWhenAbused"
                  value={medicalHistory.abuseHistory.ageWhenAbused}
                  onChange={(e) => handleAbuseHistoryChange("ageWhenAbused", e.target.value)}
                  placeholder="Age or age range"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="abuseNotes">Additional Notes</Label>
                <Textarea
                  id="abuseNotes"
                  value={medicalHistory.abuseHistory.notes}
                  onChange={(e) => handleAbuseHistoryChange("notes", e.target.value)}
                  placeholder="Any additional information about the abuse history"
                  rows={3}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="allergies">
          <AccordionTrigger>Allergies</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="aspirin"
                    checked={medicalHistory.allergies.aspirin}
                    onCheckedChange={(checked) => handleAllergiesChange("aspirin", checked === true)}
                  />
                  <Label htmlFor="aspirin">Aspirin</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ibuprofen"
                    checked={medicalHistory.allergies.ibuprofen}
                    onCheckedChange={(checked) => handleAllergiesChange("ibuprofen", checked === true)}
                  />
                  <Label htmlFor="ibuprofen">Ibuprofen</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="acetaminophen"
                    checked={medicalHistory.allergies.acetaminophen}
                    onCheckedChange={(checked) => handleAllergiesChange("acetaminophen", checked === true)}
                  />
                  <Label htmlFor="acetaminophen">Acetaminophen</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="codeine"
                    checked={medicalHistory.allergies.codeine}
                    onCheckedChange={(checked) => handleAllergiesChange("codeine", checked === true)}
                  />
                  <Label htmlFor="codeine">Codeine</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="penicillin"
                    checked={medicalHistory.allergies.penicillin}
                    onCheckedChange={(checked) => handleAllergiesChange("penicillin", checked === true)}
                  />
                  <Label htmlFor="penicillin">Penicillin</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="erythromycin"
                    checked={medicalHistory.allergies.erythromycin}
                    onCheckedChange={(checked) => handleAllergiesChange("erythromycin", checked === true)}
                  />
                  <Label htmlFor="erythromycin">Erythromycin</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="tetracycline"
                    checked={medicalHistory.allergies.tetracycline}
                    onCheckedChange={(checked) => handleAllergiesChange("tetracycline", checked === true)}
                  />
                  <Label htmlFor="tetracycline">Tetracycline</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="sulfa"
                    checked={medicalHistory.allergies.sulfa}
                    onCheckedChange={(checked) => handleAllergiesChange("sulfa", checked === true)}
                  />
                  <Label htmlFor="sulfa">Sulfa</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="localAnesthetic"
                    checked={medicalHistory.allergies.localAnesthetic}
                    onCheckedChange={(checked) => handleAllergiesChange("localAnesthetic", checked === true)}
                  />
                  <Label htmlFor="localAnesthetic">Local Anesthetic</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="fluoride"
                    checked={medicalHistory.allergies.fluoride}
                    onCheckedChange={(checked) => handleAllergiesChange("fluoride", checked === true)}
                  />
                  <Label htmlFor="fluoride">Fluoride</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="latex"
                    checked={medicalHistory.allergies.latex}
                    onCheckedChange={(checked) => handleAllergiesChange("latex", checked === true)}
                  />
                  <Label htmlFor="latex">Latex</Label>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="metals"
                    checked={medicalHistory.allergies.metals}
                    onCheckedChange={(checked) => handleAllergiesChange("metals", checked === true)}
                  />
                  <Label htmlFor="metals">Metals (nickel, gold, silver, etc.)</Label>
                </div>
                {medicalHistory.allergies.metals && (
                  <Input
                    placeholder="Specify metals"
                    value={medicalHistory.allergies.metalsDetails}
                    onChange={(e) =>
                      setMedicalHistory({
                        ...medicalHistory,
                        allergies: {
                          ...medicalHistory.allergies,
                          metalsDetails: e.target.value,
                        },
                      })
                    }
                    className="ml-6 w-[calc(100%-1.5rem)]"
                  />
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="otherAllergy"
                    checked={medicalHistory.allergies.other}
                    onCheckedChange={(checked) => handleAllergiesChange("other", checked === true)}
                  />
                  <Label htmlFor="otherAllergy">Other Allergies</Label>
                </div>
                {medicalHistory.allergies.other && (
                  <Input
                    placeholder="Specify other allergies"
                    value={medicalHistory.allergies.otherDetails}
                    onChange={(e) =>
                      setMedicalHistory({
                        ...medicalHistory,
                        allergies: {
                          ...medicalHistory.allergies,
                          otherDetails: e.target.value,
                        },
                      })
                    }
                    className="ml-6 w-[calc(100%-1.5rem)]"
                  />
                )}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="substance-use">
          <AccordionTrigger>Substance Use</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="alcohol"
                    checked={medicalHistory.substanceUse.alcohol}
                    onCheckedChange={(checked) => handleSubstanceUseChange("alcohol", checked === true)}
                  />
                  <Label htmlFor="alcohol">Alcohol</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="marijuana"
                    checked={medicalHistory.substanceUse.marijuana}
                    onCheckedChange={(checked) => handleSubstanceUseChange("marijuana", checked === true)}
                  />
                  <Label htmlFor="marijuana">Marijuana</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="prescriptionDrugs"
                    checked={medicalHistory.substanceUse.prescriptionDrugs}
                    onCheckedChange={(checked) => handleSubstanceUseChange("prescriptionDrugs", checked === true)}
                  />
                  <Label htmlFor="prescriptionDrugs">Prescription Drugs (misuse)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="inhalants"
                    checked={medicalHistory.substanceUse.inhalants}
                    onCheckedChange={(checked) => handleSubstanceUseChange("inhalants", checked === true)}
                  />
                  <Label htmlFor="inhalants">Inhalants</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="hallucinogens"
                    checked={medicalHistory.substanceUse.hallucinogens}
                    onCheckedChange={(checked) => handleSubstanceUseChange("hallucinogens", checked === true)}
                  />
                  <Label htmlFor="hallucinogens">Hallucinogens</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="amphetamines"
                    checked={medicalHistory.substanceUse.amphetamines}
                    onCheckedChange={(checked) => handleSubstanceUseChange("amphetamines", checked === true)}
                  />
                  <Label htmlFor="amphetamines">Amphetamines</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="benzodiazepines"
                    checked={medicalHistory.substanceUse.benzodiazepines}
                    onCheckedChange={(checked) => handleSubstanceUseChange("benzodiazepines", checked === true)}
                  />
                  <Label htmlFor="benzodiazepines">Benzodiazepines</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="sedatives"
                    checked={medicalHistory.substanceUse.sedatives}
                    onCheckedChange={(checked) => handleSubstanceUseChange("sedatives", checked === true)}
                  />
                  <Label htmlFor="sedatives">Sedatives</Label>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="substanceFrequency">Frequency of Use</Label>
                <Select
                  value={medicalHistory.substanceUse.frequency}
                  onValueChange={(value) => handleSubstanceUseChange("frequency", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="never">Never</SelectItem>
                    <SelectItem value="rarely">Rarely</SelectItem>
                    <SelectItem value="occasionally">Occasionally</SelectItem>
                    <SelectItem value="regularly">Regularly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="mt-4">
                <Label htmlFor="substanceUseNotes">Additional Notes</Label>
                <Textarea
                  id="substanceUseNotes"
                  value={medicalHistory.substanceUse.notes}
                  onChange={(e) => handleSubstanceUseChange("notes", e.target.value)}
                  placeholder="Any additional details about substance use"
                  rows={3}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="family-size">
          <AccordionTrigger>Family Size</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="numberOfChildren">Number of Children</Label>
                <Input
                  id="numberOfChildren"
                  type="number"
                  value={medicalHistory.familySize.numberOfChildren}
                  onChange={(e) => handleFamilySizeChange("numberOfChildren", e.target.value)}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="medical-conditions">
          <AccordionTrigger>Medical Conditions</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {/* Medical conditions checkboxes */}
                {/* This section is very long, so I'm abbreviating it for clarity */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="heartProblems"
                    checked={medicalHistory.conditions.heartProblems}
                    onCheckedChange={(checked) => handleConditionsChange("heartProblems", checked === true)}
                  />
                  <Label htmlFor="heartProblems">Heart problems</Label>
                </div>
                {/* Additional medical conditions would be listed here */}
              </div>

              <div className="mt-4">
                <Label htmlFor="conditionsNotes">Additional Notes</Label>
                <Textarea
                  id="conditionsNotes"
                  value={medicalHistory.conditions.notes}
                  onChange={(e) =>
                    setMedicalHistory({
                      ...medicalHistory,
                      conditions: {
                        ...medicalHistory.conditions,
                        notes: e.target.value,
                      },
                    })
                  }
                  placeholder="Any additional details about medical conditions"
                  rows={3}
                />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Button type="submit" className="w-full">
        Add Family Member
      </Button>
    </form>
  )
}
