interface FamilyMember {
  id: string
  name: string
  age: number
  gender: string
  relationship: string
  medicalHistory?: Array<{
    condition: string
    diagnosisYear: string
    notes: string
  }>
  children?: string[]
  detailedMedicalHistory?: {
    mentalHealth: {
      anxiety: boolean
      bipolarDisorder: boolean
      childMentalHealth: boolean
      compulsiveGambling: boolean
      delirium: boolean
      depression: boolean
      eatingDisorders: boolean
      generalMentalHealth: boolean
      moodDisorders: boolean
      ocd: boolean
      olderAdultMentalHealth: boolean
      panicDisorder: boolean
      personalityDisorders: boolean
      phobias: boolean
      ptsd: boolean
      psychoticDisorders: boolean
      schizophrenia: boolean
      selfHarm: boolean
      suicide: boolean
      alzheimers: boolean
      dementia: boolean
      notes: string
    }
    allergies: {
      aspirin: boolean
      ibuprofen: boolean
      acetaminophen: boolean
      codeine: boolean
      penicillin: boolean
      erythromycin: boolean
      tetracycline: boolean
      sulfa: boolean
      localAnesthetic: boolean
      fluoride: boolean
      metals: boolean
      metalsDetails: string
      latex: boolean
      other: boolean
      otherDetails: string
    }
    conditions: Record<string, boolean | string>
    substanceUse: {
      alcohol: boolean
      marijuana: boolean
      prescriptionDrugs: boolean
      inhalants: boolean
      hallucinogens: boolean
      amphetamines: boolean
      benzodiazepines: boolean
      sedatives: boolean
      frequency: string
      notes: string
    }
    familySize: {
      numberOfChildren: string
    }
    abuseHistory: {
      physicalAbuse: boolean
      emotionalAbuse: boolean
      sexualAbuse: boolean
      verbalAbuse: boolean
      financialAbuse: boolean
      neglect: boolean
      domesticViolence: boolean
      childAbuse: boolean
      elderAbuse: boolean
      abandoned: boolean
      adopted: boolean
      wasAbuser: boolean
      abuseDetails: string
      abuserRelationship: string
      ageWhenAbused: string
      notes: string
    }
  }
}
